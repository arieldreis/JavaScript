let pessoa = [];
let continua;
let cont = 0;
do{
    pessoa[cont] = new Pessoa();
    pessoa[cont].nome = window.prompt("Digite o nome do pasciente: ");
    do{
        pessoa.altura = window.prompt("Digite o nome do pasciente em metros: ");
    }while(pessoa.altura === null)
    do{
        pessoa[cont].peso = window.prompt("Digite o peso do pasciente em quilogramas: ");
    }while(pessoa.peso === null);
    cont++;
    continua = window.confirm("Deseja continuar: ");
}while(continua);
console.log(pessoa);
