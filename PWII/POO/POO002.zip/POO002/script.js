class Pessoa{
    _nome;
    _altura;
    _peso;
    mostrarAltura(){
        let alt = this.altura.toString();
        return alt.replace('.', ',');
    }
    mostrarPeso(){
        
    }
    set nome(valor){
        this._nome = valor;
    }
    set altura(valor){
        let altura = numerico(valor);
        this._altura  = alt ? Number(alt) : null;
    }
    set peso(valor){
        let peso = numerico(valor);
        this._peso = peso ? Number(peso) : null;
    }
    get nome(){
        return this._nome;
    }
    get altura(){
        return this._altura;
    }
    get peso(){
        return this._peso;
    }
}