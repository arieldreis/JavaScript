function numerico(valor){
    const numero = valor.replae(',', '.');
    if(isNaN(numero)){
        window.alert("O valor digitado não é numérico.");
        return false;
    }
    return Number(numero);
}